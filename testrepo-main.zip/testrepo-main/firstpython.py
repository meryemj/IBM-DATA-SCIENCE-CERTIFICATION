print("Hello first code")
